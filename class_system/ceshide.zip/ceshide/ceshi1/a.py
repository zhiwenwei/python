#-*- coding: utf-8 -*-
#AuthorZhiWenwei
import zhiww1
zhiww1.test1()